import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Plus, Trash2, Upload, Loader2, Pencil, X, Package, Search, Check } from "lucide-react";
import { toast } from "sonner";
import { optimizeImage } from "@/utils/imageOptimizer";

const EMPTY_FORM = { name: "", category: "skincare", price: "", original_price: "", short_description: "", image_url: "", gallery_urls: [], combo_product_ids: [], is_bestseller: false, is_new: false, stock_status: "in_stock" };

export default function AdminProducts() {
  const queryClient = useQueryClient();
  const [tab, setTab] = useState("products");
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState(EMPTY_FORM);
  const [editingId, setEditingId] = useState(null);
  const [uploading, setUploading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [comboSearch, setComboSearch] = useState("");

  const { data: products = [], isLoading } = useQuery({ queryKey: ["products"], queryFn: () => base44.entities.Product.list("-created_date", 200) });
  const singleProducts = products.filter(p => p.category !== "combo");
  const combos = products.filter(p => p.category === "combo");
  const filteredForCombo = singleProducts.filter(p => p.name.toLowerCase().includes(comboSearch.toLowerCase()));

  const toggleComboProduct = (productId) => {
    setForm(f => { const ids = f.combo_product_ids || []; return { ...f, combo_product_ids: ids.includes(productId) ? ids.filter(id => id !== productId) : [...ids, productId] }; });
  };

  const handleImageUpload = async (e) => {
    const file = e.target.files[0]; if (!file) return;
    setUploading(true);
    try {
      const optimized = await optimizeImage(file);
      const { file_url } = await base44.integrations.Core.UploadFile({ file: optimized });
      setForm(f => ({ ...f, image_url: file_url })); toast.success("Image uploaded!");
    } catch(err) { toast.error("Upload failed."); } finally { setUploading(false); }
  };

  const openAdd = (isCombo = false) => { setForm({ ...EMPTY_FORM, category: isCombo ? "combo" : "skincare" }); setEditingId(null); setComboSearch(""); setShowForm(true); };
  const openEdit = (product) => {
    setForm({ name: product.name || "", category: product.category || "skincare", price: product.price ?? "", original_price: product.original_price ?? "", short_description: product.short_description || "", image_url: product.image_url || "", gallery_urls: product.gallery_urls || [], combo_product_ids: product.combo_product_ids || [], is_bestseller: product.is_bestseller || false, is_new: product.is_new || false, stock_status: product.stock_status || "in_stock" });
    setEditingId(product.id); setComboSearch(""); setShowForm(true);
  };

  const handleSave = async (e) => {
    e.preventDefault(); setSaving(true);
    try {
      const data = { ...form, price: parseFloat(form.price), original_price: form.original_price ? parseFloat(form.original_price) : undefined };
      if (editingId) { await base44.entities.Product.update(editingId, data); toast.success("Product updated!"); }
      else { await base44.entities.Product.create(data); toast.success("Product added!"); }
      await queryClient.invalidateQueries({ queryKey: ["products"] });
      setShowForm(false);
    } catch(err) { toast.error("Failed to save."); } finally { setSaving(false); }
  };

  const handleDelete = async (id) => {
    if (!confirm("Delete this product?")) return;
    await base44.entities.Product.delete(id);
    queryClient.invalidateQueries({ queryKey: ["products"] });
    toast.success("Product deleted");
  };

  const isComboForm = form.category === "combo";

  return (
    <div className="pt-24 pb-20 min-h-screen">
      <div className="max-w-6xl mx-auto px-6 lg:px-8">
        <div className="flex items-center justify-between mb-8">
          <div><p className="text-[11px] uppercase tracking-ultra-wide text-muted-foreground mb-1">Admin</p><h1 className="font-display text-3xl md:text-4xl font-light">Product Management</h1></div>
          <button onClick={() => openAdd(tab === "combo")} className="flex items-center gap-2 px-5 py-2.5 bg-foreground text-background text-sm uppercase tracking-editorial hover:bg-foreground/90 transition-colors rounded-sm"><Plus className="w-4 h-4" />{tab === "combo" ? "Add Combo" : "Add Product"}</button>
        </div>
        <div className="flex gap-1 mb-8 border-b border-border">
          {[{id:"products",label:`Products (${singleProducts.length})`},{id:"combo",label:`Combos (${combos.length})`}].map(t => (
            <button key={t.id} onClick={() => setTab(t.id)} className={`px-5 py-2.5 text-sm uppercase tracking-editorial border-b-2 transition-colors -mb-px ${tab === t.id ? "border-foreground text-foreground" : "border-transparent text-muted-foreground hover:text-foreground"}`}>{t.label}</button>
          ))}
        </div>
        {isLoading ? (
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">{[...Array(8)].map((_,i) => <div key={i} className="animate-pulse"><div className="aspect-[3/4] bg-secondary rounded-sm" /><div className="mt-3 h-4 bg-secondary rounded w-3/4" /></div>)}</div>
        ) : (
          <>
            {tab === "products" && (
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
                {singleProducts.length === 0 ? <div className="col-span-4 text-center py-20"><Package className="w-12 h-12 text-border mx-auto mb-4" strokeWidth={1} /><p className="text-muted-foreground text-sm mb-4">No products yet.</p><button onClick={() => openAdd()} className="px-6 py-2.5 bg-foreground text-background text-sm uppercase tracking-editorial rounded-sm">Add First Product</button></div>
                : singleProducts.map(p => (
                  <div key={p.id} className="group relative">
                    <div className="aspect-[3/4] overflow-hidden rounded-sm bg-secondary/30 relative">
                      {p.image_url ? <img src={p.image_url} alt={p.name} className="w-full h-full object-cover" /> : <div className="w-full h-full flex items-center justify-center text-muted-foreground text-sm">No image</div>}
                      <div className="absolute inset-0 bg-foreground/0 group-hover:bg-foreground/20 transition-colors rounded-sm" />
                      <div className="absolute top-2 right-2 flex gap-1.5 opacity-0 group-hover:opacity-100 transition-opacity">
                        <button onClick={() => openEdit(p)} className="w-8 h-8 bg-background rounded-full flex items-center justify-center shadow hover:bg-secondary transition-colors"><Pencil className="w-3.5 h-3.5" /></button>
                        <button onClick={() => handleDelete(p.id)} className="w-8 h-8 bg-background rounded-full flex items-center justify-center shadow hover:bg-destructive hover:text-white transition-colors"><Trash2 className="w-3.5 h-3.5" /></button>
                      </div>
                    </div>
                    <div className="mt-3"><p className="text-sm font-medium truncate">{p.name}</p><p className="text-xs text-muted-foreground capitalize">{p.category} · ₹{p.price}</p></div>
                  </div>
                ))}
              </div>
            )}
            {tab === "combo" && (
              combos.length === 0 ? <div className="text-center py-20"><Package className="w-12 h-12 text-border mx-auto mb-4" strokeWidth={1} /><p className="text-muted-foreground text-sm mb-4">No combos yet.</p><button onClick={() => openAdd(true)} className="px-6 py-2.5 bg-foreground text-background text-sm uppercase tracking-editorial rounded-sm">Create First Combo</button></div>
              : <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {combos.map(combo => {
                  const included = (combo.combo_product_ids || []).map(id => products.find(p => p.id === id)).filter(Boolean);
                  return (
                    <div key={combo.id} className="group border border-border rounded-sm p-5 relative">
                      <div className="absolute top-3 right-3 flex gap-1.5 opacity-0 group-hover:opacity-100 transition-opacity">
                        <button onClick={() => openEdit(combo)} className="w-8 h-8 bg-background border border-border rounded-full flex items-center justify-center hover:bg-secondary transition-colors"><Pencil className="w-3.5 h-3.5" /></button>
                        <button onClick={() => handleDelete(combo.id)} className="w-8 h-8 bg-background border border-border rounded-full flex items-center justify-center hover:bg-destructive hover:text-white transition-colors"><Trash2 className="w-3.5 h-3.5" /></button>
                      </div>
                      <div className="flex items-start gap-3 mb-4">
                        {combo.image_url && <img src={combo.image_url} alt={combo.name} className="w-14 h-16 object-cover rounded-sm flex-shrink-0" />}
                        <div><p className="font-medium text-sm">{combo.name}</p><p className="text-xs text-muted-foreground mt-0.5">₹{combo.price}</p></div>
                      </div>
                      <div className="border-t border-border pt-3">
                        <p className="text-[10px] uppercase tracking-ultra-wide text-muted-foreground mb-2">Includes ({included.length} products)</p>
                        <div className="flex flex-wrap gap-1.5">{included.map(p => <span key={p.id} className="px-2 py-1 bg-secondary text-xs rounded-sm">{p.name}</span>)}</div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </>
        )}
      </div>

      {showForm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-foreground/30 backdrop-blur-sm" onClick={() => setShowForm(false)} />
          <div className="relative bg-background rounded-sm shadow-xl w-full max-w-lg max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between p-6 border-b border-border sticky top-0 bg-background z-10">
              <h2 className="font-display text-xl font-light">{editingId ? "Edit" : "Add"} {isComboForm ? "Combo" : "Product"}</h2>
              <button onClick={() => setShowForm(false)}><X className="w-5 h-5 text-muted-foreground hover:text-foreground" /></button>
            </div>
            <form onSubmit={handleSave} className="p-6 flex flex-col gap-5">
              <div>
                <label className="text-xs uppercase tracking-ultra-wide text-muted-foreground block mb-2">Product Photo</label>
                <div className="flex gap-3 items-start">
                  {form.image_url && <img src={form.image_url} alt="Preview" className="w-20 h-24 object-cover rounded-sm border border-border flex-shrink-0" />}
                  <label className={`flex-1 flex flex-col items-center justify-center gap-2 border-2 border-dashed border-border rounded-sm p-6 cursor-pointer hover:border-primary/50 transition-colors ${uploading ? "opacity-60 pointer-events-none" : ""}`}>
                    {uploading ? <Loader2 className="w-5 h-5 animate-spin text-muted-foreground" /> : <Upload className="w-5 h-5 text-muted-foreground" />}
                    <span className="text-sm text-muted-foreground">{uploading ? "Uploading..." : "Click to upload photo"}</span>
                    <input type="file" accept="image/*" className="hidden" onChange={handleImageUpload} />
                  </label>
                </div>
              </div>
              <div><label className="text-xs uppercase tracking-ultra-wide text-muted-foreground block mb-2">Product Name *</label><input required value={form.name} onChange={(e) => setForm(f => ({...f, name: e.target.value}))} className="w-full border border-border rounded-sm px-4 py-2.5 text-sm focus:outline-none focus:ring-1 focus:ring-primary bg-background" /></div>
              {!isComboForm && (
                <div><label className="text-xs uppercase tracking-ultra-wide text-muted-foreground block mb-2">Category *</label>
                  <select value={form.category} onChange={(e) => setForm(f => ({...f, category: e.target.value}))} className="w-full border border-border rounded-sm px-4 py-2.5 text-sm focus:outline-none focus:ring-1 focus:ring-primary bg-background">
                    <option value="skincare">Skincare</option><option value="haircare">Haircare</option>
                  </select>
                </div>
              )}
              {isComboForm && (
                <div>
                  <label className="text-xs uppercase tracking-ultra-wide text-muted-foreground block mb-2">Select Products for Combo{form.combo_product_ids.length > 0 && <span className="ml-2 text-primary normal-case tracking-normal">({form.combo_product_ids.length} selected)</span>}</label>
                  <div className="relative mb-2"><Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" /><input type="text" placeholder="Search products..." value={comboSearch} onChange={(e) => setComboSearch(e.target.value)} className="w-full border border-border rounded-sm pl-9 pr-4 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-primary bg-background" /></div>
                  <div className="border border-border rounded-sm max-h-52 overflow-y-auto divide-y divide-border">
                    {filteredForCombo.map(p => { const selected = (form.combo_product_ids || []).includes(p.id); return (
                      <button key={p.id} type="button" onClick={() => toggleComboProduct(p.id)} className={`w-full flex items-center gap-3 px-4 py-3 text-left hover:bg-secondary/50 transition-colors ${selected ? "bg-primary/5" : ""}`}>
                        {p.image_url ? <img src={p.image_url} alt={p.name} className="w-9 h-11 object-cover rounded-sm flex-shrink-0" /> : <div className="w-9 h-11 bg-secondary rounded-sm flex-shrink-0" />}
                        <div className="flex-1 min-w-0"><p className="text-sm font-medium truncate">{p.name}</p><p className="text-xs text-muted-foreground capitalize">{p.category} · ₹{p.price}</p></div>
                        <div className={`w-5 h-5 rounded-sm border flex items-center justify-center flex-shrink-0 ${selected ? "bg-primary border-primary" : "border-border"}`}>{selected && <Check className="w-3 h-3 text-white" />}</div>
                      </button>
                    ); })}
                  </div>
                </div>
              )}
              <div className="grid grid-cols-2 gap-4">
                <div><label className="text-xs uppercase tracking-ultra-wide text-muted-foreground block mb-2">Price *</label><input required type="number" step="0.01" value={form.price} onChange={(e) => setForm(f => ({...f, price: e.target.value}))} className="w-full border border-border rounded-sm px-4 py-2.5 text-sm focus:outline-none focus:ring-1 focus:ring-primary bg-background" placeholder="0.00" /></div>
                <div><label className="text-xs uppercase tracking-ultra-wide text-muted-foreground block mb-2">Original Price</label><input type="number" step="0.01" value={form.original_price} onChange={(e) => setForm(f => ({...f, original_price: e.target.value}))} className="w-full border border-border rounded-sm px-4 py-2.5 text-sm focus:outline-none focus:ring-1 focus:ring-primary bg-background" placeholder="0.00" /></div>
              </div>
              <div><label className="text-xs uppercase tracking-ultra-wide text-muted-foreground block mb-2">Short Description *</label><textarea required rows={3} value={form.short_description} onChange={(e) => setForm(f => ({...f, short_description: e.target.value}))} className="w-full border border-border rounded-sm px-4 py-2.5 text-sm focus:outline-none focus:ring-1 focus:ring-primary bg-background resize-none" /></div>
              <div><label className="text-xs uppercase tracking-ultra-wide text-muted-foreground block mb-2">Stock Status</label>
                <select value={form.stock_status} onChange={(e) => setForm(f => ({...f, stock_status: e.target.value}))} className="w-full border border-border rounded-sm px-4 py-2.5 text-sm focus:outline-none focus:ring-1 focus:ring-primary bg-background">
                  <option value="in_stock">In Stock</option><option value="low_stock">Low Stock</option><option value="out_of_stock">Out of Stock</option>
                </select>
              </div>
              <div className="flex gap-6">
                <label className="flex items-center gap-2 text-sm cursor-pointer"><input type="checkbox" checked={form.is_bestseller} onChange={(e) => setForm(f => ({...f, is_bestseller: e.target.checked}))} className="rounded" />Bestseller</label>
                <label className="flex items-center gap-2 text-sm cursor-pointer"><input type="checkbox" checked={form.is_new} onChange={(e) => setForm(f => ({...f, is_new: e.target.checked}))} className="rounded" />New Arrival</label>
              </div>
              <button type="submit" disabled={saving || uploading} className="w-full py-3 bg-foreground text-background text-sm uppercase tracking-editorial hover:bg-foreground/90 transition-colors rounded-sm disabled:opacity-60 flex items-center justify-center gap-2">
                {saving && <Loader2 className="w-4 h-4 animate-spin" />}{editingId ? "Save Changes" : isComboForm ? "Create Combo" : "Add Product"}
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
